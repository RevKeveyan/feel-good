﻿# Feel Good Mobile — установка на другом ПК

## Что внутри

- `apps/mobile` — Expo-приложение
- `packages/shared` — общий пакет (нужен для `npm install`)

## Требования

- Node.js 18+ (LTS)
- npm
- Expo Go на телефоне (SDK 52 / Expo Go 2.32.19 для этого проекта) или Android/iOS эмулятор

## Запуск

```powershell
cd feel-good-mobile\apps\mobile
npm install
npx expo start
```

При странном кэше:

```powershell
npx expo start -c
```

Откройте проект в Expo Go (QR) или эмуляторе.

## Env

Файл `apps/mobile/.env` уже может быть в архиве (ваш Supabase).  
Если его нет — скопируйте `.env.example` → `.env` и заполните:

- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `EXPO_PUBLIC_MINDSET_AUDIO_BASE_URL` (опционально)

Не публикуйте этот zip с `.env` третьим лицам.
