import * as AppleAuthentication from "expo-apple-authentication";
import * as AuthSession from "expo-auth-session";
import * as WebBrowser from "expo-web-browser";
import { Platform } from "react-native";
import { supabase } from "./supabase";

WebBrowser.maybeCompleteAuthSession();

const oauthRedirectTo = AuthSession.makeRedirectUri({
  scheme: "feelgood",
  path: "auth/callback",
});
const resetRedirectTo = AuthSession.makeRedirectUri({
  scheme: "feelgood",
  path: "auth/reset",
});

if (__DEV__) {
  console.log("[auth] oauthRedirectTo", oauthRedirectTo);
  console.log("[auth] resetRedirectTo", resetRedirectTo);
}

export function parseAuthCallbackUrl(url: string): {
  access_token: string | null;
  refresh_token: string | null;
  type: string | null;
} {
  const hashIndex = url.indexOf("#");
  const queryIndex = url.indexOf("?");
  const hashParams = hashIndex >= 0 ? url.slice(hashIndex + 1) : "";
  const queryParams =
    queryIndex >= 0 ? url.slice(queryIndex + 1, hashIndex >= 0 ? hashIndex : undefined) : "";
  const params = new URLSearchParams(hashParams || queryParams);
  if (hashParams && queryParams) {
    const query = new URLSearchParams(queryParams);
    for (const [key, value] of query.entries()) {
      if (!params.has(key)) params.set(key, value);
    }
  }
  return {
    access_token: params.get("access_token"),
    refresh_token: params.get("refresh_token"),
    type: params.get("type"),
  };
}

export async function completeSessionFromUrl(url: string) {
  const { access_token, refresh_token } = parseAuthCallbackUrl(url);
  if (!access_token || !refresh_token) {
    throw new Error("Auth callback missing tokens");
  }
  const { error } = await supabase.auth.setSession({ access_token, refresh_token });
  if (error) throw error;
}

export async function signInWithEmail(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

export async function signUpWithEmail(email: string, password: string, displayName: string) {
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { display_name: displayName } },
  });
  if (error) throw error;
}

export async function requestPasswordReset(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: resetRedirectTo,
  });
  if (error) throw error;
}

export async function verifyRecoveryOtp(email: string, token: string) {
  const { error } = await supabase.auth.verifyOtp({
    email,
    token: token.trim(),
    type: "recovery",
  });
  if (error) throw error;
}

export async function updatePassword(newPassword: string) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

export async function signInWithGoogle() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo: oauthRedirectTo,
      skipBrowserRedirect: true,
    },
  });
  if (error) throw error;
  if (!data.url) throw new Error("No OAuth URL returned");

  if (__DEV__) {
    try {
      const redirectParam = new URL(data.url).searchParams.get("redirect_to");
      console.log("[auth] oauthRedirectTo", oauthRedirectTo);
      console.log("[auth] supabase redirect_to param", redirectParam);
    } catch {
      console.log("[auth] oauth url", data.url);
    }
  }

  const result = await WebBrowser.openAuthSessionAsync(data.url, oauthRedirectTo);
  if (result.type !== "success" || !result.url) {
    throw new Error("Google sign in cancelled");
  }

  await completeSessionFromUrl(result.url);
}

export async function signInWithApple() {
  if (Platform.OS !== "ios") {
    throw new Error("Apple Sign In is only available on iOS");
  }
  const credential = await AppleAuthentication.signInAsync({
    requestedScopes: [
      AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
      AppleAuthentication.AppleAuthenticationScope.EMAIL,
    ],
  });
  if (!credential.identityToken) {
    throw new Error("No identity token from Apple");
  }
  const { error } = await supabase.auth.signInWithIdToken({
    provider: "apple",
    token: credential.identityToken,
  });
  if (error) throw error;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export { oauthRedirectTo as redirectTo, resetRedirectTo };
